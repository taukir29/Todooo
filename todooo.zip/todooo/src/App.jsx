import { useState } from "react";
import "./style.css";

function App() {
  const [newItem, setNewItem] = useState("");
  const [todos, setTodos] = useState([]);

  function handleSubmit(e) {
    e.preventDefault();

    setTodos((prevtodos) => [
      ...prevtodos,
      { id: crypto.randomUUID(), title: newItem, completed: false },
    ]);

    // Clear the input field after submitting
    setNewItem("");
  }

  function toggletodo(id) {
    setTodos((prevTodos) =>
      prevTodos.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  }

  function deletetodo(id) {
    setTodos((prevTodos) => prevTodos.filter((item) => item.id !== id));
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="new-item-form">
        <div className="form-row">
          <label htmlFor="item">New Item</label>
          <input
            type="text"
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            id="item"
          />
        </div>
        <button className="btn">Add</button>
      </form>
      <h1 className="header">ToDoo List</h1>
      <ul className="list">
        {todos.map((todo) => (
          <li key={todo.id}>
            <label>
              <input
                type="checkbox"
                checked={todo.completed}
                onChange={() => toggletodo(todo.id)}
              />
              {todo.title}
            </label>
            <button
              className="btn btn-danger"
              onClick={() => deletetodo(todo.id)}
            >
              X
            </button>
          </li>
        ))}
      </ul>
    </>
  );
}

export default App;
